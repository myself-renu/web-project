export type ShortItem = { id: string; title: string };
export const SHORTS: ShortItem[] = [
  { id: "-XcTMb8_KXE", title: "Clutch Montage" },
  { id: "0lG-3YGrjng", title: "Redstone Trick" },
  { id: "wlg-bzvh72M", title: "Speedrun Moment" },
  { id: "XtPP2UWjWoE", title: "Epic Build Time-lapse" },
];
